import pygame
import sys
pygame.init()

#ekraani sätted
screen = pygame.display.set_mode((640, 480)) #640x480pikslit suur
pygame.display.set_caption("Automäng") #Pealkiri aknal

#Kaadrid
clock = pygame.time.Clock()

#Taustapilt
bg_rally = pygame.image.load("bg_rally.jpg")

#Punane auto
red = pygame.image.load("f1_red.png")

#Sinine auto
blue = pygame.image.load("f1_blue.png")

#Font skoori teksti jaoks
font = pygame.font.Font(None, 36)

skoor = 0 #Algväärtus punktisüsteemi jaoks

#Autode asukohad Y = väärtused + kiiruse väärtus
blue1Y = 130
blue2Y = 10
speedY = 5

#Mängu jooksmise tingimus
running = True
#Mängu sulgemine ristist
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False #Kui vajutatakse ristile, mäng sulgub

    #Liigutab vasakpoolset sinist autot allapoole
    blue1Y += speedY
    if blue1Y > 480:
        blue1Y = -20 #Kui auto jõuab Y=480 väärtusest välja paigutatakse auto tagasi akna ülemises äärde
        skoor += 1 #Igakord, kui auto liigub vastu alumist äärt, lisatakse 1 punkt


    blue2Y += speedY
    if blue2Y > 480:
        blue2Y = -20 #Kui auto jõuab Y=480 väärtusest välja paigutatakse auto tagasi akna ülemises äärde
        skoor += 1 #Igakord, kui autp liigub vastu alumist äärt, lisatakse 1 punkt


    screen.blit(bg_rally, (0, 0))  #Joonistab tausta
    screen.blit(red, (300, 380))  #Joonistab punase auto
    screen.blit(blue, (180, blue1Y))#Vasakpoolne sinine auto
    screen.blit(blue, (420, blue2Y))#Parempoolne sinine auto

    #Skoori ekraanile saamiseks
    skoor_tekst = font.render(f"Skoor: {skoor}", True, (255, 0, 255))
    screen.blit(skoor_tekst, (10,10))

    clock.tick(60) #Kontrollib kaadrisagedust
    pygame.display.flip() #Uuendab ekraani

#Mängu sulgedes lõpetatakse pygame ja suletakse rakendus
pygame.quit()
sys.exit()


